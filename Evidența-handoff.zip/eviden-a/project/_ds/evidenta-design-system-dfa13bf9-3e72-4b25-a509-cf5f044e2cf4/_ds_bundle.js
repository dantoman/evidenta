/* @ds-bundle: {"format":4,"namespace":"EvidentaDesignSystem_dfa13b","components":[{"name":"Crest","sourcePath":"components/brand/Crest.jsx"},{"name":"Ornament","sourcePath":"components/brand/Ornament.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"Figure","sourcePath":"components/data/Figure.jsx"},{"name":"StatTile","sourcePath":"components/data/StatTile.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/Crest.jsx":"6f1b45f986af","components/brand/Ornament.jsx":"2e312a6c4a5a","components/core/Badge.jsx":"ade8e7f31fed","components/core/Button.jsx":"dca86d17b51a","components/core/Card.jsx":"0998ea1f8ba2","components/core/Icon.jsx":"736354eed292","components/core/IconButton.jsx":"fe1a526c69c1","components/core/Tag.jsx":"5ad3f9370b70","components/data/DataTable.jsx":"7deb69c827f8","components/data/Figure.jsx":"4b67ca1376a3","components/data/StatTile.jsx":"f75e9b1ef02e","components/feedback/Dialog.jsx":"b8aa4024c842","components/feedback/EmptyState.jsx":"3146f02da575","components/feedback/Toast.jsx":"26a4b4f768bb","components/feedback/Tooltip.jsx":"6234ff476da3","components/forms/Checkbox.jsx":"b29e3c14d685","components/forms/Field.jsx":"e23e3fc68941","components/forms/Input.jsx":"d2ef53937c66","components/forms/Radio.jsx":"d7e9e16828fc","components/forms/Select.jsx":"db7b64a2d9d8","components/forms/Switch.jsx":"53a26868eeca","components/navigation/Breadcrumbs.jsx":"462378173cfd","components/navigation/Tabs.jsx":"afac48a4693e","ui_kits/evidenta-app/AppShell.jsx":"628c1fa8a49b","ui_kits/evidenta-app/Dashboard.jsx":"f5a57c6e93d6","ui_kits/evidenta-app/DocumentForm.jsx":"847a6cd1a005","ui_kits/evidenta-app/Journal.jsx":"b1ccbdcae27c","ui_kits/evidenta-app/Login.jsx":"4eb1b72181d4","ui_kits/evidenta-app/Reports.jsx":"b200fd893db5","ui_kits/evidenta-app/data.js":"e2347eec37bd"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EvidentaDesignSystem_dfa13b = window.EvidentaDesignSystem_dfa13b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Crest.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 28,
  md: 40,
  lg: 64,
  xl: 96
};

/**
 * The Evidenta crest lockup. Uses the supplied raster emblem — never redraw it.
 * @param base Relative path to the project root (where /assets lives).
 */
function Crest({
  size = 'md',
  wordmark = true,
  tagline,
  tone = 'navy',
  base = '../..',
  style,
  ...rest
}) {
  const px = SIZES[size] || SIZES.md;
  const onNavy = tone === 'light';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: px > 44 ? 'var(--space-4)' : 'var(--space-3)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: `${base}/assets/emblem-crest.png`,
    alt: "Evidenta",
    style: {
      height: px,
      width: px,
      objectFit: 'contain',
      flex: '0 0 auto'
    }
  }), wordmark ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--font-display)',
      fontWeight: 700,
      fontSize: Math.round(px * 0.44),
      lineHeight: 1,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: onNavy ? 'var(--text-on-navy)' : 'var(--navy-700)'
    }
  }, "Evidenta"), tagline ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--font-eyebrow)',
      fontWeight: 600,
      fontSize: Math.max(9, Math.round(px * 0.20)),
      lineHeight: 1.1,
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: onNavy ? 'var(--gold-400)' : 'var(--gold-700)'
    }
  }, tagline === true ? 'Autoritate în contabilitate' : tagline) : null) : null);
}
Object.assign(__ds_scope, { Crest });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Crest.jsx", error: String((e && e.message) || e) }); }

// components/brand/Ornament.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Laurel / ribbon / column ornaments from the crest, for headers, print covers and dividers. */
function Ornament({
  kind = 'laurel-pair',
  height = 48,
  opacity = 1,
  base = '../..',
  style,
  ...rest
}) {
  const src = {
    laurel: 'laurel-branch-gold.png',
    ribbon: 'ribbon-banner-navy.png',
    column: 'column-navy.png',
    owl: 'owl-outline-gold.png',
    ring: 'circular-border-navy.png'
  };
  if (kind === 'laurel-pair') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 'var(--space-4)',
        opacity,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("img", {
      src: `${base}/assets/laurel-branch-gold.png`,
      alt: "",
      style: {
        height,
        transform: 'scaleX(-1)'
      }
    }), /*#__PURE__*/React.createElement("img", {
      src: `${base}/assets/laurel-branch-gold.png`,
      alt: "",
      style: {
        height
      }
    }));
  }
  if (kind === 'rule') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        opacity,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        height: 1,
        flex: 1,
        background: 'var(--gold-500)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 5,
        height: 5,
        background: 'var(--gold-500)',
        transform: 'rotate(45deg)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        height: 1,
        flex: 1,
        background: 'var(--gold-500)'
      }
    }));
  }
  return /*#__PURE__*/React.createElement("img", _extends({
    src: `${base}/assets/${src[kind] || src.laurel}`,
    alt: "",
    style: {
      height,
      opacity,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Ornament });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Ornament.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    background: 'var(--ink-100)',
    color: 'var(--ink-700)',
    border: 'var(--ink-200)'
  },
  navy: {
    background: 'var(--navy-050)',
    color: 'var(--navy-700)',
    border: 'var(--navy-100)'
  },
  gold: {
    background: 'var(--gold-100)',
    color: 'var(--gold-900)',
    border: 'var(--gold-200)'
  },
  credit: {
    background: 'var(--credit-100)',
    color: 'var(--credit-700)',
    border: '#C8E0D2'
  },
  debit: {
    background: 'var(--debit-100)',
    color: 'var(--debit-700)',
    border: '#EFC9C4'
  },
  caution: {
    background: 'var(--caution-100)',
    color: 'var(--caution-700)',
    border: '#EFD9A8'
  },
  info: {
    background: 'var(--info-100)',
    color: 'var(--info-700)',
    border: '#C3DCE7'
  }
};
function Badge({
  tone = 'neutral',
  dot,
  children,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: 22,
      padding: '0 8px',
      borderRadius: 'var(--radius-xs)',
      background: t.background,
      color: t.color,
      border: `1px solid ${t.border}`,
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'currentColor'
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  tone = 'default',
  padding = 'var(--gutter-card)',
  crestRule,
  title,
  eyebrow,
  actions,
  children,
  style,
  ...rest
}) {
  const tones = {
    default: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-hairline)',
      boxShadow: 'var(--shadow-card)'
    },
    sunken: {
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-hairline)',
      boxShadow: 'none'
    },
    inverse: {
      background: 'var(--surface-inverse)',
      border: '1px solid var(--navy-700)',
      boxShadow: 'var(--shadow-raised)',
      color: 'var(--text-on-navy)'
    },
    outline: {
      background: 'transparent',
      border: '1px solid var(--border-strong)',
      boxShadow: 'none'
    }
  };
  const inverse = tone === 'inverse';
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden',
      ...tones[tone],
      ...style
    }
  }, rest), crestRule ? /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--border-width-crest)',
      background: 'var(--gradient-gold-foil)'
    }
  }) : null, title || eyebrow || actions ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      padding: `${padding} ${padding} 0`
    }
  }, /*#__PURE__*/React.createElement("div", null, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: inverse ? 'var(--gold-400)' : 'var(--gold-700)',
      marginBottom: 'var(--space-1)'
    }
  }, eyebrow) : null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-title)',
      color: inverse ? 'var(--text-on-navy)' : 'var(--text-heading)',
      margin: 0
    }
  }, title) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      flex: '0 0 auto'
    }
  }, actions) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = 'https://cdn.jsdelivr.net/npm/lucide-static@latest/icons';
const cache = {};

/** Lucide outline icon, inlined so its strokes inherit currentColor. */
function Icon({
  name = 'circle',
  size = 18,
  label,
  style,
  ...rest
}) {
  const [svg, setSvg] = React.useState(cache[name] || null);
  React.useEffect(() => {
    if (cache[name]) {
      setSvg(cache[name]);
      return;
    }
    let alive = true;
    fetch(`${CDN}/${name}.svg`).then(r => r.ok ? r.text() : '').then(t => {
      if (!t) return;
      const marked = t.replace('<svg', '<svg style="display:block;width:100%;height:100%"');
      cache[name] = marked;
      if (alive) setSvg(marked);
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, [name]);
  return /*#__PURE__*/React.createElement("span", _extends({
    role: label ? 'img' : 'presentation',
    "aria-label": label,
    "aria-hidden": label ? undefined : true,
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      flex: '0 0 auto',
      lineHeight: 0,
      ...style
    },
    dangerouslySetInnerHTML: svg ? {
      __html: svg
    } : undefined
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    height: 'var(--control-height-sm)',
    padding: '0 12px',
    font: 'var(--text-body-sm)',
    icon: 15
  },
  md: {
    height: 'var(--control-height-md)',
    padding: '0 18px',
    font: 'var(--text-body-md)',
    icon: 17
  },
  lg: {
    height: 'var(--control-height-lg)',
    padding: '0 24px',
    font: 'var(--text-body-lg)',
    icon: 19
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--accent-primary)',
    color: 'var(--text-on-navy)',
    border: '1px solid var(--accent-primary)',
    boxShadow: 'var(--shadow-card)'
  },
  gold: {
    background: 'var(--accent-gold)',
    color: 'var(--text-on-gold)',
    border: '1px solid var(--accent-gold-hover)',
    boxShadow: 'var(--shadow-card)'
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-heading)',
    border: '1px solid var(--border-strong)',
    boxShadow: 'var(--shadow-card)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-link)',
    border: '1px solid transparent',
    boxShadow: 'none'
  },
  danger: {
    background: 'var(--debit-500)',
    color: '#fff',
    border: '1px solid var(--debit-700)',
    boxShadow: 'var(--shadow-card)'
  }
};
const HOVER = {
  primary: {
    background: 'var(--accent-primary-hover)',
    borderColor: 'var(--accent-primary-hover)'
  },
  gold: {
    background: 'var(--accent-gold-hover)',
    borderColor: 'var(--accent-gold-active)'
  },
  secondary: {
    background: 'var(--navy-050)',
    borderColor: 'var(--navy-300)'
  },
  ghost: {
    background: 'var(--navy-050)'
  },
  danger: {
    background: 'var(--debit-700)'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconAfter,
  block,
  disabled,
  type = 'button',
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: block ? 'flex' : 'inline-flex',
      width: block ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 'var(--space-2)',
      height: s.height,
      padding: s.padding,
      font: s.font,
      fontWeight: 600,
      letterSpacing: 'var(--tracking-tight)',
      borderRadius: 'var(--radius-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control), transform var(--duration-instant) var(--ease-standard)',
      transform: press && !disabled ? 'scale(var(--press-scale))' : 'none',
      opacity: disabled ? 0.42 : 1,
      ...(VARIANTS[variant] || VARIANTS.primary),
      ...(hover && !disabled ? HOVER[variant] : null),
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }) : null, children, iconAfter ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconAfter,
    size: s.icon
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 32,
  md: 40,
  lg: 48
};
function IconButton({
  icon = 'ellipsis',
  label,
  size = 'md',
  variant = 'ghost',
  disabled,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const px = SIZES[size] || SIZES.md;
  const base = variant === 'solid' ? {
    background: 'var(--accent-primary)',
    color: 'var(--text-on-navy)',
    border: '1px solid var(--accent-primary)'
  } : variant === 'outline' ? {
    background: 'var(--surface-card)',
    color: 'var(--text-heading)',
    border: '1px solid var(--border-strong)'
  } : {
    background: 'transparent',
    color: 'var(--text-muted)',
    border: '1px solid transparent'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: px,
      height: px,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      opacity: disabled ? 0.42 : 1,
      ...base,
      ...(hover && !disabled ? variant === 'solid' ? {
        background: 'var(--accent-primary-hover)'
      } : {
        background: 'var(--navy-050)',
        color: 'var(--text-heading)'
      } : null),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 16 : size === 'lg' ? 20 : 18
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  onRemove,
  tone = 'neutral',
  style,
  ...rest
}) {
  const navy = tone === 'navy';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: 26,
      padding: onRemove ? '0 6px 0 10px' : '0 10px',
      borderRadius: 'var(--radius-pill)',
      background: navy ? 'var(--navy-700)' : 'var(--surface-sunken)',
      color: navy ? 'var(--text-on-navy)' : 'var(--text-body)',
      border: `1px solid ${navy ? 'var(--navy-700)' : 'var(--border-hairline)'}`,
      font: 'var(--text-body-sm)',
      ...style
    }
  }, rest), children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onRemove,
    "aria-label": "Elimin\u0103",
    style: {
      display: 'inline-flex',
      padding: 2,
      border: 0,
      background: 'transparent',
      color: 'inherit',
      cursor: 'pointer',
      opacity: 0.7,
      borderRadius: 999
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function DataTable({
  columns = [],
  rows = [],
  density = 'default',
  onRowClick,
  footer,
  style,
  ...rest
}) {
  const h = density === 'dense' ? 'var(--row-height-dense)' : density === 'comfy' ? 'var(--row-height-comfy)' : 'var(--row-height)';
  const [hover, setHover] = React.useState(-1);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      overflowX: 'auto',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      font: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '0 12px',
      height: 34,
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      background: 'var(--surface-sunken)',
      borderTop: '1px solid var(--border-hairline)',
      borderBottom: '1px solid var(--border-hairline)',
      whiteSpace: 'nowrap',
      width: c.width
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4
    }
  }, c.label, c.sorted ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: c.sorted === 'desc' ? 'arrow-down' : 'arrow-up',
    size: 12
  }) : null))))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: r.id != null ? r.id : i,
    onClick: onRowClick ? () => onRowClick(r, i) : undefined,
    onMouseEnter: () => setHover(i),
    onMouseLeave: () => setHover(-1),
    style: {
      background: hover === i ? 'var(--navy-050)' : 'transparent',
      cursor: onRowClick ? 'pointer' : 'default',
      transition: 'background-color var(--duration-instant) var(--ease-standard)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      padding: '0 12px',
      height: h,
      textAlign: c.align || 'left',
      borderBottom: '1px solid var(--border-hairline)',
      color: 'var(--text-body)',
      verticalAlign: 'middle',
      whiteSpace: 'nowrap'
    }
  }, c.render ? c.render(r) : r[c.key]))))), footer ? /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", null, columns.map((c, i) => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      padding: '0 12px',
      height: 'var(--row-height)',
      textAlign: c.align || 'left',
      borderTop: '2px solid var(--rule-gold)',
      font: 'var(--text-label)',
      color: 'var(--text-heading)'
    }
  }, footer[c.key] != null ? footer[c.key] : i === 0 ? 'Total' : null)))) : null));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/Figure.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const fmt = (n, currency) => {
  const neg = n < 0;
  const [int, dec] = Math.abs(n).toFixed(2).split('.');
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, '\u202F');
  return (neg ? '\u2212' : '') + grouped + ',' + dec + (currency ? ' ' + currency : '');
};

/** Every monetary amount in Evidenta renders through Figure: tabular mono, ro-MD grouping. */
function Figure({
  value = 0,
  currency,
  size = 'md',
  signed,
  tone,
  style,
  ...rest
}) {
  const num = typeof value === 'number' ? value : parseFloat(value) || 0;
  // signed only marks negatives — colouring every positive amount green makes registers noisy.
  const t = tone || (signed && num < 0 ? 'negative' : 'neutral');
  const color = t === 'negative' ? 'var(--figure-negative)' : t === 'positive' ? 'var(--figure-positive)' : 'var(--text-heading)';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      font: size === 'lg' ? 'var(--text-figure-lg)' : size === 'sm' ? 'var(--text-figure-sm)' : 'var(--text-figure-md)',
      fontVariantNumeric: 'tabular-nums',
      color,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), typeof value === 'string' ? value : fmt(num, currency));
}
Object.assign(__ds_scope, { Figure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Figure.jsx", error: String((e && e.message) || e) }); }

// components/data/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatTile({
  label,
  value,
  currency,
  delta,
  deltaLabel,
  icon,
  tone = 'default',
  style,
  ...rest
}) {
  const inverse = tone === 'inverse';
  const up = typeof delta === 'number' && delta > 0;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      padding: 'var(--space-5)',
      borderRadius: 'var(--radius-card)',
      background: inverse ? 'var(--gradient-crest)' : 'var(--surface-card)',
      border: `1px solid ${inverse ? 'var(--navy-800)' : 'var(--border-hairline)'}`,
      boxShadow: inverse ? 'var(--shadow-raised)' : 'var(--shadow-card)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: inverse ? 'var(--gold-400)' : 'var(--text-muted)'
    }
  }, label), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    style: {
      color: inverse ? 'var(--gold-400)' : 'var(--ink-300)'
    }
  }) : null), /*#__PURE__*/React.createElement(__ds_scope.Figure, {
    value: value,
    currency: currency,
    size: "lg",
    style: {
      color: inverse ? 'var(--text-on-navy)' : 'var(--text-heading)'
    }
  }), delta != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      font: 'var(--text-caption)',
      color: inverse ? 'var(--navy-200)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: up ? 'trending-up' : 'trending-down',
    size: 14,
    style: {
      color: up ? 'var(--credit-500)' : 'var(--debit-500)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-figure-sm)',
      color: up ? 'var(--figure-positive)' : 'var(--figure-negative)'
    }
  }, up ? '+' : '−', Math.abs(delta), "%"), deltaLabel) : null);
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = true,
  title,
  eyebrow,
  footer,
  width = 520,
  onClose,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeItems: 'center',
      background: 'rgba(6,21,39,.42)',
      backdropFilter: 'blur(2px)',
      zIndex: 60,
      padding: 'var(--space-6)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-sheet)',
      boxShadow: 'var(--shadow-overlay)',
      border: '1px solid var(--border-hairline)',
      overflow: 'hidden',
      animation: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 'var(--border-width-crest)',
      background: 'var(--gradient-gold-foil)'
    }
  }), /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      padding: '20px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("div", null, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--gold-700)'
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-display-3)',
      color: 'var(--text-heading)',
      margin: '4px 0 0'
    }
  }, title)), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "\xCEnchide",
    size: "sm",
    onClick: onClose
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 24px 24px',
      font: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, children), footer ? /*#__PURE__*/React.createElement("footer", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-3)',
      padding: '16px 24px',
      background: 'var(--surface-sunken)',
      borderTop: '1px solid var(--border-hairline)'
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function EmptyState({
  title,
  description,
  action,
  mark = '../../assets/owl-outline-gold.png',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 'var(--space-3)',
      padding: 'var(--space-12) var(--space-6)',
      border: '1px dashed var(--border-strong)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--surface-sunken)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: mark,
    alt: "",
    style: {
      height: 56,
      width: 'auto',
      opacity: 0.55
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--text-display-3)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-muted)',
      margin: 0,
      maxWidth: '46ch'
    }
  }, description) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-2)'
    }
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  success: {
    icon: 'circle-check',
    accent: 'var(--credit-500)'
  },
  error: {
    icon: 'octagon-alert',
    accent: 'var(--debit-500)'
  },
  caution: {
    icon: 'triangle-alert',
    accent: 'var(--caution-500)'
  },
  info: {
    icon: 'info',
    accent: 'var(--info-500)'
  }
};
function Toast({
  tone = 'info',
  title,
  children,
  onClose,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      width: 'min(420px, 100%)',
      padding: '14px 14px 14px 16px',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-card)',
      border: '1px solid var(--border-hairline)',
      boxShadow: 'var(--shadow-overlay)',
      borderLeft: 'none',
      position: 'relative',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: t.accent
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 18,
    style: {
      color: t.accent,
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-heading)'
    }
  }, title) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, children) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "\xCEnchide",
    size: "sm",
    onClick: onClose
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  content,
  placement = 'top',
  children,
  style,
  ...rest
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translate(-50%, -8px)'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translate(-50%, 8px)'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translate(-8px, -50%)'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translate(8px, -50%)'
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, rest), children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 70,
      padding: '6px 10px',
      maxWidth: 260,
      width: 'max-content',
      background: 'var(--navy-800)',
      color: 'var(--text-on-navy)',
      font: 'var(--text-caption)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-raised)',
      pointerEvents: 'none',
      opacity: show ? 1 : 0,
      transition: 'opacity var(--duration-fast) var(--ease-standard)'
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked,
  indeterminate,
  disabled,
  label,
  description,
  onChange,
  style,
  ...rest
}) {
  const on = !!checked || !!indeterminate;
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: description ? 'flex-start' : 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: '0 0 auto',
      marginTop: description ? 2 : 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-xs)',
      background: on ? 'var(--accent-primary)' : 'var(--surface-card)',
      border: `1px solid ${on ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
      boxShadow: on ? 'none' : 'var(--shadow-inset-field)',
      color: 'var(--text-on-navy)',
      transition: 'var(--transition-control)'
    }
  }, indeterminate ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "minus",
    size: 13
  }) : checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 13
  }) : null), label ? /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      font: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, description) : null) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Label + help/error scaffold shared by every Evidenta form control. */
function Field({
  label,
  hint,
  error,
  required,
  htmlFor,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: htmlFor,
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-heading)',
      display: 'flex',
      gap: 4
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--debit-500)'
    }
  }, "*") : null) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-caption)',
      color: 'var(--debit-700)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  icon,
  suffix,
  invalid,
  disabled,
  align,
  numeric,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      width: '100%'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    style: {
      position: 'absolute',
      left: 12,
      color: 'var(--text-faint)'
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    disabled: disabled,
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      width: '100%',
      height: 'var(--control-height-md)',
      padding: `0 ${suffix ? 44 : 12}px 0 ${icon ? 34 : 12}px`,
      font: numeric ? 'var(--text-figure-md)' : 'var(--text-body-md)',
      fontVariantNumeric: numeric ? 'tabular-nums' : undefined,
      textAlign: align || (numeric ? 'right' : 'left'),
      color: 'var(--text-body)',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1px solid ${invalid ? 'var(--debit-500)' : focus ? 'var(--border-focus)' : 'var(--border-hairline)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
      outline: 'none',
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 12,
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      pointerEvents: 'none'
    }
  }, suffix) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  checked,
  disabled,
  label,
  description,
  name,
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: description ? 'flex-start' : 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: '0 0 auto',
      marginTop: description ? 2 : 0,
      borderRadius: 999,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-card)',
      border: `1px solid ${checked ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
      boxShadow: checked ? 'none' : 'var(--shadow-inset-field)',
      transition: 'var(--transition-control)'
    }
  }, checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: 'var(--accent-primary)'
    }
  }) : null), label ? /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      font: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, description) : null) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  options = [],
  invalid,
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: 'var(--control-height-md)',
      padding: '0 36px 0 12px',
      font: 'var(--text-body-md)',
      color: 'var(--text-body)',
      appearance: 'none',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1px solid ${invalid ? 'var(--debit-500)' : focus ? 'var(--border-focus)' : 'var(--border-hairline)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
      outline: 'none',
      transition: 'var(--transition-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, rest), options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    style: {
      position: 'absolute',
      right: 12,
      color: 'var(--text-muted)',
      pointerEvents: 'none'
    }
  }));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked,
  disabled,
  label,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 22,
      borderRadius: 999,
      flex: '0 0 auto',
      padding: 2,
      display: 'inline-flex',
      alignItems: 'center',
      background: checked ? 'var(--accent-primary)' : 'var(--ink-300)',
      transition: 'background-color var(--duration-fast) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 999,
      background: 'var(--white)',
      boxShadow: 'var(--shadow-card)',
      transform: checked ? 'translateX(16px)' : 'translateX(0)',
      transition: 'transform var(--duration-fast) var(--ease-standard)'
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-body)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumbs({
  items = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      ...style
    }
  }, rest), items.map((raw, i) => {
    const it = typeof raw === 'string' ? {
      label: raw
    } : raw;
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, last ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-heading)',
        fontWeight: 600
      }
    }, it.label) : /*#__PURE__*/React.createElement("a", {
      href: it.href || '#',
      style: {
        color: 'var(--text-link)',
        textDecoration: 'none'
      }
    }, it.label), last ? null : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: 13,
      style: {
        color: 'var(--ink-300)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  onChange,
  style,
  ...rest
}) {
  const active = value != null ? value : items[0] && (items[0].value || items[0]);
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      borderBottom: '1px solid var(--border-hairline)',
      ...style
    }
  }, rest), items.map(raw => {
    const it = typeof raw === 'string' ? {
      value: raw,
      label: raw
    } : raw;
    const on = it.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": on,
      type: "button",
      onClick: () => onChange && onChange(it.value),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 'var(--space-2)',
        padding: '0 0 10px',
        background: 'none',
        border: 0,
        cursor: 'pointer',
        font: 'var(--text-label)',
        fontSize: 14,
        color: on ? 'var(--text-heading)' : 'var(--text-muted)',
        borderBottom: `2px solid ${on ? 'var(--accent-gold)' : 'transparent'}`,
        marginBottom: -1,
        transition: 'var(--transition-control)'
      }
    }, it.label, it.count != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--text-figure-sm)',
        color: 'var(--text-faint)'
      }
    }, it.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/AppShell.jsx
try { (() => {
const {
  Crest,
  Icon,
  IconButton,
  Input,
  Badge,
  Tooltip
} = window.EvidentaDesignSystem_dfa13b;
function SidebarNav({
  active,
  onNavigate
}) {
  const [hover, setHover] = React.useState(null);
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--sidebar-width)',
      flex: '0 0 auto',
      background: 'var(--gradient-crest)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 18px',
      borderBottom: '1px solid rgba(198,161,91,.22)'
    }
  }, /*#__PURE__*/React.createElement(Crest, {
    size: "sm",
    tone: "light",
    base: "../.."
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: '14px 10px',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      flex: 1
    }
  }, window.EV_DATA.nav.map(n => {
    const on = n.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      type: "button",
      onClick: () => onNavigate(n.id),
      onMouseEnter: () => setHover(n.id),
      onMouseLeave: () => setHover(null),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        height: 'var(--row-height)',
        padding: '0 12px',
        border: 0,
        cursor: 'pointer',
        textAlign: 'left',
        borderRadius: 'var(--radius-control)',
        background: on ? 'rgba(198,161,91,.16)' : hover === n.id ? 'rgba(255,255,255,.06)' : 'transparent',
        color: on ? 'var(--parchment-100)' : 'var(--navy-200)',
        font: 'var(--text-body-md)',
        fontWeight: on ? 600 : 400,
        boxShadow: on ? 'inset 2px 0 0 var(--gold-500)' : 'none',
        transition: 'var(--transition-control)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 18,
      style: {
        color: on ? 'var(--gold-400)' : 'var(--navy-300)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, n.label), n.count ? /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--text-figure-sm)',
        color: 'var(--navy-300)'
      }
    }, n.count) : null);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 18px',
      borderTop: '1px solid rgba(198,161,91,.22)',
      font: 'var(--text-caption)',
      color: 'var(--navy-300)'
    }
  }, "Perioada \xB7 ", window.EV_DATA.company.period, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4,
      color: 'var(--gold-400)',
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase'
    }
  }, "Conform SNC")));
}
function Topbar({
  onNewDoc
}) {
  const c = window.EV_DATA.company,
    u = window.EV_DATA.user;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 'var(--topbar-height)',
      flex: '0 0 auto',
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '0 var(--gutter-page)',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      height: 40,
      padding: '0 12px',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-control)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "building-2",
    size: 16,
    style: {
      color: 'var(--navy-500)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-heading)',
      whiteSpace: 'nowrap'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-figure-sm)',
      color: 'var(--text-faint)',
      whiteSpace: 'nowrap'
    }
  }, c.idno), /*#__PURE__*/React.createElement(Icon, {
    name: "chevrons-up-down",
    size: 14,
    style: {
      color: 'var(--text-faint)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 380
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    placeholder: "Caut\u0103 document, cont sau contragent"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Sincronizat cu SFS acum 4 minute"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "credit",
    dot: true
  }, "SFS")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Notific\u0103ri"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "circle-help",
    label: "Ajutor"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 28,
      background: 'var(--border-hairline)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      background: 'var(--navy-700)',
      color: 'var(--gold-400)',
      display: 'grid',
      placeItems: 'center',
      font: 'var(--text-label)'
    }
  }, "AR"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.25,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-heading)'
    }
  }, u.name), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, u.role))));
}
function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      marginBottom: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", null, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--gold-700)',
      marginBottom: 6
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display-2)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-md)',
      color: 'var(--text-muted)',
      margin: '8px 0 0',
      maxWidth: '62ch'
    }
  }, description) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flex: '0 0 auto'
    }
  }, actions) : null), children);
}
function AppShell({
  active,
  onNavigate,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      height: '100%',
      minHeight: 0,
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement(SidebarNav, {
    active: active,
    onNavigate: onNavigate
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Topbar, null), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: 'var(--gutter-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--content-max)',
      margin: '0 auto'
    }
  }, children))));
}
Object.assign(window, {
  AppShell,
  SidebarNav,
  Topbar,
  PageHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/Dashboard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Card,
  Button,
  IconButton,
  Badge,
  Tag,
  Icon,
  Input,
  Select,
  Field,
  Checkbox,
  Switch,
  Tabs,
  Breadcrumbs,
  Dialog,
  Toast,
  Tooltip,
  EmptyState,
  Figure,
  DataTable,
  StatTile,
  Ornament
} = window.EvidentaDesignSystem_dfa13b;
function Dashboard({
  onNavigate
}) {
  const d = window.EV_DATA;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHeader, {
    eyebrow: d.company.period,
    title: "Panou de control",
    description: "Situa\u0163ia contabil\u0103 a companiei la 18 iunie 2026.",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "download"
    }, "Export"), /*#__PURE__*/React.createElement(Button, {
      icon: "file-plus",
      onClick: () => onNavigate('form')
    }, "Not\u0103 contabil\u0103 nou\u0103"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-4)'
    }
  }, d.stats.map(s => /*#__PURE__*/React.createElement(StatTile, _extends({
    key: s.label
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 'var(--space-4)',
      marginTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    eyebrow: "Ultimele \xEEnregistr\u0103ri",
    title: "Documente",
    padding: "0",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      iconAfter: "arrow-right",
      onClick: () => onNavigate('journal')
    }, "Vezi jurnalul")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 0 4px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    density: "dense",
    onRowClick: () => onNavigate('journal'),
    columns: [{
      key: 'id',
      label: 'Nr.',
      width: 92,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--text-figure-sm)',
          color: 'var(--text-link)'
        }
      }, r.id)
    }, {
      key: 'date',
      label: 'Data',
      width: 92
    }, {
      key: 'contragent',
      label: 'Contragent'
    }, {
      key: 'suma',
      label: 'Suma',
      align: 'right',
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.suma
      })
    }, {
      key: 'stare',
      label: 'Stare',
      width: 130,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: {
          "Înregistrat": "credit",
          "În aşteptare": "caution",
          "Ciornă": "info",
          "Respins": "debit"
        }[r.stare]
      }, r.stare)
    }],
    rows: d.documents.slice(0, 5)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    crestRule: true,
    eyebrow: "Termen apropiat",
    title: "Declara\u0163ia TVA-12",
    padding: "20px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Figure, {
    value: "25.06.2026",
    size: "lg"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "\xEEn 7 zile")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      background: 'var(--surface-sunken)',
      borderRadius: 999,
      margin: '14px 0 10px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '72%',
      height: '100%',
      background: 'var(--gradient-gold-foil)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "72% din documentele perioadei sunt \xEEnregistrate."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    block: true,
    icon: "receipt",
    style: {
      marginTop: 16
    }
  }, "Preg\u0103te\u015Fte declara\u0163ia")), /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    eyebrow: "De verificat",
    title: "Aten\u0163ion\u0103ri",
    padding: "20px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [['triangle-alert', 'var(--caution-700)', '2 documente fără factură fiscală atașată'], ['circle-slash', 'var(--debit-700)', 'NC-00416 respinsă de contragent'], ['info', 'var(--info-700)', 'Cursul BNM a fost actualizat']].map(([ic, col, tx]) => /*#__PURE__*/React.createElement("div", {
    key: tx,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 16,
    style: {
      color: col,
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, tx))))))));
}
Object.assign(window, {
  Dashboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/DocumentForm.jsx
try { (() => {
const {
  Card,
  Button,
  IconButton,
  Badge,
  Tag,
  Icon,
  Input,
  Select,
  Field,
  Checkbox,
  Switch,
  Tabs,
  Breadcrumbs,
  Dialog,
  Toast,
  Tooltip,
  EmptyState,
  Figure,
  DataTable,
  StatTile,
  Ornament
} = window.EvidentaDesignSystem_dfa13b;
function DocumentForm({
  onNavigate
}) {
  const d = window.EV_DATA;
  const [lines, setLines] = React.useState(d.lines);
  const debit = lines.reduce((a, l) => a + l.debit, 0);
  const credit = lines.reduce((a, l) => a + l.credit, 0);
  const balanced = Math.abs(debit - credit) < 0.005;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: [{
      label: 'Contabilitate',
      href: '#'
    }, {
      label: 'Jurnal',
      href: '#'
    }, {
      label: 'NC-00422'
    }],
    style: {
      marginBottom: 'var(--space-4)'
    }
  }), /*#__PURE__*/React.createElement(PageHeader, {
    eyebrow: "Ciorn\u0103 \xB7 nesalvat\u0103",
    title: "Not\u0103 contabil\u0103 nou\u0103",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => onNavigate('journal')
    }, "Anuleaz\u0103"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "save"
    }, "Salveaz\u0103 ciorna"), /*#__PURE__*/React.createElement(Button, {
      icon: "check",
      disabled: !balanced
    }, "\xCEnregistreaz\u0103"))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 'var(--space-4)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    eyebrow: "Antet",
    title: "Documentul primar"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Tip document",
    required: true
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Factură fiscală', 'Aviz de însoţire', 'Bon de plată', 'Extras bancar']
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Seria \u015Fi num\u0103rul",
    required: true
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "AAA 0184552"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Data documentului",
    required: true
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "calendar",
    defaultValue: "18.06.2026"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Data \xEEnregistr\u0103rii"
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "calendar",
    defaultValue: "18.06.2026"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Contragent",
    required: true,
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "building-2",
    defaultValue: "ICS \"Termocom\" SRL \xB7 1002600045871"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Suma f\u0103r\u0103 TVA",
    required: true
  }, /*#__PURE__*/React.createElement(Input, {
    numeric: true,
    suffix: "MDL",
    defaultValue: "39 120,00"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "TVA 20%"
  }, /*#__PURE__*/React.createElement(Input, {
    numeric: true,
    suffix: "MDL",
    defaultValue: "9 780,00"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Descriere",
    hint: "Apare \xEEn registrul jurnal",
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    defaultValue: "Servicii de termoficare, iunie 2026"
  })))), /*#__PURE__*/React.createElement(Card, {
    eyebrow: "Dubla \xEEnregistrare",
    title: "Formule contabile",
    padding: "0",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: "plus",
      onClick: () => setLines(lines.concat([{
        cont: '',
        den: 'Selectaţi contul',
        debit: 0,
        credit: 0
      }]))
    }, "Adaug\u0103 r\xE2nd")
  }, /*#__PURE__*/React.createElement(DataTable, {
    density: "default",
    columns: [{
      key: 'cont',
      label: 'Cont',
      width: 90,
      render: l => /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--text-figure-md)',
          color: l.cont ? 'var(--text-heading)' : 'var(--text-faint)'
        }
      }, l.cont || '—')
    }, {
      key: 'den',
      label: 'Denumirea contului'
    }, {
      key: 'debit',
      label: 'Debit',
      align: 'right',
      width: 130,
      render: l => l.debit ? /*#__PURE__*/React.createElement(Figure, {
        value: l.debit
      }) : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-faint)'
        }
      }, "\u2014")
    }, {
      key: 'credit',
      label: 'Credit',
      align: 'right',
      width: 130,
      render: l => l.credit ? /*#__PURE__*/React.createElement(Figure, {
        value: l.credit
      }) : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-faint)'
        }
      }, "\u2014")
    }, {
      key: 'act',
      label: '',
      width: 44,
      align: 'right',
      render: () => /*#__PURE__*/React.createElement(IconButton, {
        icon: "trash-2",
        label: "Elimin\u0103 r\xE2ndul",
        size: "sm"
      })
    }],
    rows: lines,
    footer: {
      debit: /*#__PURE__*/React.createElement(Figure, {
        value: debit
      }),
      credit: /*#__PURE__*/React.createElement(Figure, {
        value: credit
      })
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: balanced ? 'circle-check' : 'octagon-alert',
    size: 16,
    style: {
      color: balanced ? 'var(--credit-500)' : 'var(--debit-500)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: balanced ? 'var(--credit-700)' : 'var(--debit-700)'
    }
  }, balanced ? 'Debitul şi creditul sunt egale — nota poate fi înregistrată.' : 'Debitul şi creditul nu sunt egale.')))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    eyebrow: "Sintez\u0103",
    title: "Total document",
    padding: "20px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, [['Fără TVA', 39120], ['TVA 20%', 9780]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement(Figure, {
    value: v,
    size: "sm"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 2,
      background: 'var(--rule-gold)',
      margin: '4px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, "Total"), /*#__PURE__*/React.createElement(Figure, {
    value: 48900,
    currency: "MDL",
    size: "lg"
  })))), /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    eyebrow: "Op\u0163iuni",
    title: "Procesare",
    padding: "20px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: true,
    label: "Trimite la SFS (e-Factura)"
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Genereaz\u0103 plata automat"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: true,
    label: "Ata\u015Feaz\u0103 la dosarul lunii"
  }))), /*#__PURE__*/React.createElement(Card, {
    tone: "outline",
    padding: "20px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "paperclip",
    size: 16,
    style: {
      color: 'var(--text-faint)',
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-label)',
      color: 'var(--text-heading)'
    }
  }, "Fi\u015Fiere ata\u015Fate"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "Niciun fi\u015Fier. Trage\u0163i factura scanat\u0103 aici.")))))));
}
Object.assign(window, {
  DocumentForm
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/DocumentForm.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/Journal.jsx
try { (() => {
const {
  Card,
  Button,
  IconButton,
  Badge,
  Tag,
  Icon,
  Input,
  Select,
  Field,
  Checkbox,
  Switch,
  Tabs,
  Breadcrumbs,
  Dialog,
  Toast,
  Tooltip,
  EmptyState,
  Figure,
  DataTable,
  StatTile,
  Ornament
} = window.EvidentaDesignSystem_dfa13b;
const STARE_TONE = {
  "Înregistrat": "credit",
  "În aşteptare": "caution",
  "Ciornă": "info",
  "Respins": "debit"
};
function Journal({
  onNavigate
}) {
  const d = window.EV_DATA;
  const [tab, setTab] = React.useState('toate');
  const [posting, setPosting] = React.useState(null);
  const [toast, setToast] = React.useState(null);
  const rows = tab === 'toate' ? d.documents : d.documents.filter(r => tab === 'asteptare' ? r.stare === 'În aşteptare' : r.stare === 'Ciornă');
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: [{
      label: 'Contabilitate',
      href: '#'
    }, {
      label: 'Registrul jurnal'
    }],
    style: {
      marginBottom: 'var(--space-4)'
    }
  }), /*#__PURE__*/React.createElement(PageHeader, {
    eyebrow: d.company.period,
    title: "Registrul jurnal",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "printer"
    }, "Tip\u0103re\u015Fte"), /*#__PURE__*/React.createElement(Button, {
      icon: "file-plus",
      onClick: () => onNavigate('form')
    }, "Not\u0103 contabil\u0103 nou\u0103"))
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      value: 'toate',
      label: 'Toate',
      count: d.documents.length
    }, {
      value: 'asteptare',
      label: 'În aşteptare',
      count: 1
    }, {
      value: 'ciorne',
      label: 'Ciorne',
      count: 1
    }]
  })), /*#__PURE__*/React.createElement(Card, {
    padding: "0"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      padding: 'var(--space-4)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 260
    }
  }, /*#__PURE__*/React.createElement(Input, {
    icon: "search",
    placeholder: "Caut\u0103 \xEEn jurnal"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 170
    }
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Toate tipurile', 'Factură fiscală', 'Extras bancar', 'Bon de plată']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 150
    }
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Iunie 2026', 'Mai 2026', 'Aprilie 2026']
  })), /*#__PURE__*/React.createElement(Tag, {
    onRemove: () => {}
  }, "Cont 5311"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "Afi\u015Feaz\u0103 \u015Fi documentele stornate"
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Stornate"
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "sliders-horizontal",
    label: "Filtre avansate",
    variant: "outline"
  })), /*#__PURE__*/React.createElement(DataTable, {
    density: "default",
    columns: [{
      key: 'sel',
      label: '',
      width: 40,
      render: () => /*#__PURE__*/React.createElement(Checkbox, null)
    }, {
      key: 'id',
      label: 'Nr. notă',
      width: 100,
      sorted: 'desc',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--text-figure-sm)',
          color: 'var(--text-link)',
          fontWeight: 500
        }
      }, r.id)
    }, {
      key: 'date',
      label: 'Data',
      width: 96
    }, {
      key: 'tip',
      label: 'Tip document',
      width: 150
    }, {
      key: 'contragent',
      label: 'Contragent'
    }, {
      key: 'suma',
      label: 'Suma',
      align: 'right',
      width: 120,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.suma
      })
    }, {
      key: 'tva',
      label: 'TVA',
      align: 'right',
      width: 110,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.tva,
        size: "sm",
        style: {
          color: 'var(--text-muted)'
        }
      })
    }, {
      key: 'stare',
      label: 'Stare',
      width: 132,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: STARE_TONE[r.stare],
        dot: r.stare === 'Înregistrat'
      }, r.stare)
    }, {
      key: 'act',
      label: '',
      width: 96,
      align: 'right',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'inline-flex',
          gap: 2
        }
      }, /*#__PURE__*/React.createElement(IconButton, {
        icon: "pencil",
        label: "Editeaz\u0103",
        size: "sm",
        onClick: () => onNavigate('form')
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "check",
        label: "\xCEnregistreaz\u0103",
        size: "sm",
        onClick: () => setPosting(r)
      }))
    }],
    rows: rows,
    footer: {
      suma: /*#__PURE__*/React.createElement(Figure, {
        value: rows.reduce((a, r) => a + r.suma, 0)
      }),
      tva: /*#__PURE__*/React.createElement(Figure, {
        value: rows.reduce((a, r) => a + r.tva, 0)
      })
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, rows.length, " din 128 documente"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    icon: "chevron-left"
  }, "Anterior"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconAfter: "chevron-right"
  }, "Urm\u0103tor")))), posting ? /*#__PURE__*/React.createElement(Dialog, {
    eyebrow: "Confirmare",
    title: "\xCEnregistreaz\u0103 nota contabil\u0103?",
    width: 440,
    onClose: () => setPosting(null),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setPosting(null)
    }, "Anuleaz\u0103"), /*#__PURE__*/React.createElement(Button, {
      icon: "check",
      onClick: () => {
        setToast(posting.id);
        setPosting(null);
      }
    }, "\xCEnregistreaz\u0103"))
  }, "Nota ", /*#__PURE__*/React.createElement("strong", {
    style: {
      font: 'var(--text-figure-md)'
    }
  }, posting.id), " \xEEn valoare de ", /*#__PURE__*/React.createElement(Figure, {
    value: posting.suma,
    currency: "MDL"
  }), " va fi \xEEnregistrat\u0103 \xEEn jurnal \u015Fi nu va mai putea fi editat\u0103.") : null, toast ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 24,
      bottom: 24,
      zIndex: 80
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    title: `Nota ${toast} a fost înregistrată`,
    onClose: () => setToast(null)
  }, "Jurnalul \u015Fi balan\u0163a au fost actualizate.")) : null);
}
Object.assign(window, {
  Journal
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/Journal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/Login.jsx
try { (() => {
const {
  Crest,
  Ornament,
  Button,
  Input,
  Field,
  Checkbox,
  Icon
} = window.EvidentaDesignSystem_dfa13b;
function Login({
  onSignIn
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '46%',
      flex: '0 0 auto',
      background: 'var(--gradient-crest)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      padding: '48px 44px',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/circular-border-navy.png",
    alt: "",
    style: {
      position: 'absolute',
      right: -170,
      bottom: -140,
      width: 520,
      opacity: 0.12
    }
  }), /*#__PURE__*/React.createElement(Crest, {
    size: "sm",
    tone: "light",
    base: "../.."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/emblem-crest.png",
    alt: "",
    style: {
      height: 132,
      marginBottom: 24
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display-1)',
      color: 'var(--parchment-100)',
      margin: 0,
      maxWidth: '18ch'
    }
  }, "Eviden\u0163a contabil\u0103, \xEEntr-un singur registru."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginTop: 22,
      maxWidth: 380
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      flex: 1,
      background: 'var(--gold-600)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--gold-400)'
    }
  }, "Sistem contabil fundamental"), /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      flex: 1,
      background: 'var(--gold-600)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-caption)',
      color: 'var(--navy-300)'
    }
  }, "Conform SNC \u015Fi Planului general de conturi contabile al Republicii Moldova.")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      placeItems: 'center',
      padding: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 380
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--gold-700)'
    }
  }, "Autentificare"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--text-display-3)',
      color: 'var(--text-heading)',
      margin: '6px 0 4px'
    }
  }, "Intra\u0163i \xEEn cont"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      margin: '0 0 24px'
    }
  }, "Utiliza\u0163i datele emise de administratorul companiei."), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onSignIn();
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Adres\u0103 de e-mail",
    required: true,
    htmlFor: "ev-mail"
  }, /*#__PURE__*/React.createElement(Input, {
    id: "ev-mail",
    icon: "mail",
    defaultValue: "ana.rusu@codru-agro.md"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Parol\u0103",
    required: true,
    htmlFor: "ev-pass"
  }, /*#__PURE__*/React.createElement(Input, {
    id: "ev-pass",
    type: "password",
    icon: "lock",
    defaultValue: "parola-demo"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: true,
    label: "\u0162ine-m\u0103 minte"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-link)',
      textDecoration: 'none'
    }
  }, "A\u0163i uitat parola?")), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    block: true,
    size: "lg",
    iconAfter: "arrow-right"
  }, "Continu\u0103"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    block: true,
    icon: "id-card",
    type: "button"
  }, "Semn\u0103tur\u0103 mobil\u0103 (MSign)")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(Ornament, {
    kind: "rule",
    style: {
      maxWidth: 260,
      margin: '0 auto'
    }
  })))));
}
Object.assign(window, {
  Login
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/Login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/Reports.jsx
try { (() => {
const {
  Card,
  Button,
  IconButton,
  Badge,
  Tag,
  Icon,
  Input,
  Select,
  Field,
  Checkbox,
  Switch,
  Tabs,
  Breadcrumbs,
  Dialog,
  Toast,
  Tooltip,
  EmptyState,
  Figure,
  DataTable,
  StatTile,
  Ornament
} = window.EvidentaDesignSystem_dfa13b;
function Reports() {
  const d = window.EV_DATA;
  const [view, setView] = React.useState('balanta');
  const t = d.balance.reduce((a, r) => ({
    sid: a.sid + r.sid,
    debit: a.debit + r.debit,
    credit: a.credit + r.credit
  }), {
    sid: 0,
    debit: 0,
    credit: 0
  });
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PageHeader, {
    eyebrow: d.company.period,
    title: "Balan\u0163a de verificare",
    description: "Rulaje \u015Fi solduri pe conturi, conform Planului general de conturi contabile.",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "printer"
    }, "Tip\u0103re\u015Fte"), /*#__PURE__*/React.createElement(Button, {
      variant: "gold",
      icon: "file-down"
    }, "Export oficial"))
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: view,
    onChange: setView,
    items: [{
      value: 'balanta',
      label: 'Balanţa de verificare'
    }, {
      value: 'cartea',
      label: 'Cartea mare'
    }, {
      value: 'tva',
      label: 'Registrul TVA'
    }]
  })), view === 'balanta' ? /*#__PURE__*/React.createElement(Card, {
    padding: "0",
    crestRule: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 'var(--space-5) var(--space-5) var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-title)',
      color: 'var(--text-heading)'
    }
  }, d.company.name), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-caption)',
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "IDNO ", d.company.idno, " \xB7 perioada 01.04.2026 \u2014 30.06.2026")), /*#__PURE__*/React.createElement(Ornament, {
    kind: "rule",
    style: {
      width: 180
    }
  })), /*#__PURE__*/React.createElement(DataTable, {
    density: "dense",
    columns: [{
      key: 'cont',
      label: 'Cont',
      width: 84,
      sorted: 'asc',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          font: 'var(--text-figure-md)',
          color: 'var(--text-heading)'
        }
      }, r.cont)
    }, {
      key: 'den',
      label: 'Denumirea contului'
    }, {
      key: 'sid',
      label: 'Sold iniţial',
      align: 'right',
      width: 140,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.sid,
        signed: true
      })
    }, {
      key: 'debit',
      label: 'Rulaj debit',
      align: 'right',
      width: 140,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.debit
      })
    }, {
      key: 'credit',
      label: 'Rulaj credit',
      align: 'right',
      width: 140,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.credit
      })
    }, {
      key: 'sf',
      label: 'Sold final',
      align: 'right',
      width: 140,
      render: r => /*#__PURE__*/React.createElement(Figure, {
        value: r.sid + r.debit - r.credit,
        signed: true
      })
    }],
    rows: d.balance,
    footer: {
      sid: /*#__PURE__*/React.createElement(Figure, {
        value: t.sid,
        signed: true
      }),
      debit: /*#__PURE__*/React.createElement(Figure, {
        value: t.debit
      }),
      credit: /*#__PURE__*/React.createElement(Figure, {
        value: t.credit
      }),
      sf: /*#__PURE__*/React.createElement(Figure, {
        value: t.sid + t.debit - t.credit,
        signed: true
      })
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: 'var(--space-4) var(--space-5)',
      background: 'var(--surface-sunken)',
      borderTop: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "credit",
    dot: true
  }, "Balan\u0163\u0103 \xEEnchis\u0103"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Rulajele debitoare \u015Fi creditoare corespund. Generat la 18.06.2026, 14:22."))) : /*#__PURE__*/React.createElement(EmptyState, {
    mark: "../../assets/owl-outline-gold.png",
    title: view === 'cartea' ? 'Cartea mare nu a fost generată' : 'Registrul TVA este gol pentru această perioadă',
    description: "Aceast\u0103 vedere nu a fost furnizat\u0103 \xEEn materialele surs\u0103 \u015Fi este l\u0103sat\u0103 inten\u0163ionat necompletat\u0103.",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "refresh-cw"
    }, "Genereaz\u0103")
  }));
}
Object.assign(window, {
  Reports
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/Reports.jsx", error: String((e && e.message) || e) }); }

// ui_kits/evidenta-app/data.js
try { (() => {
window.EV_DATA = {
  company: {
    name: 'SRL "Codru-Agro"',
    idno: '1003600012345',
    period: 'Trimestrul II 2026'
  },
  user: {
    name: 'Ana Rusu',
    role: 'Contabil-şef'
  },
  stats: [{
    label: 'Rulaj lunar',
    value: 841320,
    currency: 'MDL',
    delta: 4.2,
    deltaLabel: 'faţă de luna trecută',
    icon: 'scale',
    tone: 'inverse'
  }, {
    label: 'TVA de plată',
    value: 41880,
    currency: 'MDL',
    delta: -2.1,
    deltaLabel: 'trimestrial',
    icon: 'receipt'
  }, {
    label: 'Creanţe scadente',
    value: 312500,
    currency: 'MDL',
    delta: 1.4,
    deltaLabel: '30+ zile',
    icon: 'clock'
  }, {
    label: 'Disponibil în casă',
    value: 128400,
    currency: 'MDL',
    icon: 'wallet'
  }],
  documents: [{
    id: 'NC-00421',
    date: '18.06.2026',
    tip: 'Factură fiscală',
    contragent: 'ICS "Termocom" SRL',
    suma: 48900,
    tva: 9780,
    stare: 'Înregistrat'
  }, {
    id: 'NC-00420',
    date: '17.06.2026',
    tip: 'Bon de plată',
    contragent: 'Casa — Ana Rusu',
    suma: 3210.5,
    tva: 0,
    stare: 'Înregistrat'
  }, {
    id: 'NC-00419',
    date: '17.06.2026',
    tip: 'Factură fiscală',
    contragent: 'SA "Franzeluţa"',
    suma: 12480,
    tva: 2496,
    stare: 'În aşteptare'
  }, {
    id: 'NC-00418',
    date: '16.06.2026',
    tip: 'Extras bancar',
    contragent: 'BC "Moldindconbank"',
    suma: 214600,
    tva: 0,
    stare: 'Înregistrat'
  }, {
    id: 'NC-00417',
    date: '15.06.2026',
    tip: 'Aviz de însoţire',
    contragent: 'SRL "Agroteh"',
    suma: 7312.4,
    tva: 1462.48,
    stare: 'Ciornă'
  }, {
    id: 'NC-00416',
    date: '15.06.2026',
    tip: 'Factură fiscală',
    contragent: 'SRL "Vinuri de Comrat"',
    suma: 96320,
    tva: 19264,
    stare: 'Respins'
  }],
  balance: [{
    cont: '1123',
    den: 'Mijloace fixe',
    sid: 1284000,
    debit: 0,
    credit: 42000
  }, {
    cont: '2113',
    den: 'Materiale de bază',
    sid: 218400,
    debit: 96320,
    credit: 74100
  }, {
    cont: '2213',
    den: 'Creanţe comerciale',
    sid: 312500,
    debit: 489000,
    credit: 312500
  }, {
    cont: '5311',
    den: 'Casa în valută naţională',
    sid: 128400,
    debit: 128400,
    credit: 96320
  }, {
    cont: '5344',
    den: 'Datorii privind TVA',
    sid: -41880,
    debit: 7312.4,
    credit: 41880
  }, {
    cont: '5211',
    den: 'Datorii comerciale',
    sid: -186300,
    debit: 74100,
    credit: 214600
  }, {
    cont: '6111',
    den: 'Venituri din vânzări',
    sid: 0,
    debit: 0,
    credit: 841320
  }, {
    cont: '7111',
    den: 'Costul vânzărilor',
    sid: 0,
    debit: 512900,
    credit: 0
  }],
  lines: [{
    cont: '2213',
    den: 'Creanţe comerciale',
    debit: 48900,
    credit: 0
  }, {
    cont: '6111',
    den: 'Venituri din vânzări',
    debit: 0,
    credit: 39120
  }, {
    cont: '5344',
    den: 'Datorii privind TVA',
    debit: 0,
    credit: 9780
  }],
  nav: [{
    id: 'dashboard',
    label: 'Panou de control',
    icon: 'layout-dashboard'
  }, {
    id: 'journal',
    label: 'Registrul jurnal',
    icon: 'book-open',
    count: 128
  }, {
    id: 'form',
    label: 'Notă contabilă nouă',
    icon: 'file-plus'
  }, {
    id: 'reports',
    label: 'Balanţa de verificare',
    icon: 'scale'
  }, {
    id: 'accounts',
    label: 'Plan de conturi',
    icon: 'folder-tree'
  }, {
    id: 'partners',
    label: 'Contragenţi',
    icon: 'users'
  }, {
    id: 'vat',
    label: 'Declaraţii TVA',
    icon: 'receipt'
  }, {
    id: 'settings',
    label: 'Setări',
    icon: 'settings'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/evidenta-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Crest = __ds_scope.Crest;

__ds_ns.Ornament = __ds_scope.Ornament;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.Figure = __ds_scope.Figure;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
