# Evidenta — Design System

**Evidenta** is an accounting application for the **Republic of Moldova**, built around the
double-entry ledger: primary documents in, journal entries and trial balance out, VAT declarations
filed to the SFS. Its identity is deliberately institutional — an **owl** (vigilance, judgement)
perched on a **classical column** (the ledger as a load-bearing structure), framed in **laurel** and
banded by a **ribbon** reading *SISTEM CONTABIL FUNDAMENTAL*. Two colours carry everything: **marine
navy** and **gold**, printed on **parchment**.

Taglines supplied with the brand, verbatim:

- `SISTEM CONTABIL FUNDAMENTAL` — on the ribbon, inside the crest
- `AUTORITATE ÎN CONTABILITATE` — under the wordmark

Interface language is **Romanian (ro-MD)**.

---

## Sources given to me

| Source | What it was | Access |
|---|---|---|
| `Evidenta/` (mounted local folder) | 26 raster images: 10 transparent PNG **crest layers** (emblem, owl ×3, laurel ×4, ribbon ×2, column, circular border) and 16 JPEG **logo lockup explorations** | Read fully |
| Chat brief | "accounting app for R Moldova, called EVIDENTA, as icon I selected owl, colours blue marine and gold" | — |

### ⚠️ What was **not** provided — read this before trusting anything below

1. **No source code.** The folder labelled as a codebase contains only images. There is no product
   code, component library, or stylesheet to derive from.
2. **No product screens.** Not a single screenshot, Figma file or wireframe of the actual
   application was supplied.
3. **No font files and no named typefaces.** The typography below is a **substitution** — nearest
   Google Fonts matches to the lettering visible in the lockup images.
4. **No icon set.** Iconography is a **substitution** — Lucide, chosen for its 2px outline weight,
   which sits closest to the crest's line work.
5. **No copy deck.** The content-fundamentals section below is inferred from the two supplied
   taglines plus Moldovan accounting-register conventions.

Consequences: **tokens, colours and brand assets are canonical** (measured from the supplied art).
**Type, icons, component inventory and the UI kit's layout/IA are proposals** — see the ASK at the
bottom of this file.

---

## Index

| Path | What it is |
|---|---|
| `styles.css` | Global CSS entry point — `@import` list only. Consumers link this one file. |
| `tokens/fonts.css` | Font stacks + the Google Fonts substitution (see caveats) |
| `tokens/colors.css` | Navy / gold / parchment / ink ramps + semantic aliases |
| `tokens/typography.css` | `--text-*` composite font shorthands + tracking |
| `tokens/spacing.css` | 4px scale, gutters, row and control heights, layout widths |
| `tokens/radius.css` | Corner radii and border widths |
| `tokens/elevation.css` | Shadows, focus rings, brand gradients, parchment texture |
| `tokens/motion.css` | Durations, easings, press scale, reduced-motion override |
| `guidelines/*.html` | 20 foundation specimen cards (Colors, Type, Spacing, Brand) |
| `components/` | 23 React primitives, grouped by concern |
| `ui_kits/evidenta-app/` | Click-through recreation of the accounting app — **read its README first** |
| `assets/` | Supplied crest layers and logo lockups |
| `SKILL.md` | Agent-Skills entry point for use outside this project |

### Components

Grouped by concern. Each has a sibling `.d.ts` (props contract) and `.prompt.md` (when & how).

- `components/core/` — **Icon**, **Button**, **IconButton**, **Card**, **Badge**, **Tag**
- `components/forms/` — **Field**, **Input**, **Select**, **Checkbox**, **Radio**, **Switch**
- `components/navigation/` — **Tabs**, **Breadcrumbs**
- `components/feedback/` — **Dialog**, **Toast**, **Tooltip**, **EmptyState**
- `components/data/` — **Figure**, **DataTable**, **StatTile**
- `components/brand/` — **Crest**, **Ornament**

Because no source defined a component inventory, this is the standard primitive set, sized to an
accounting product. **Intentional additions** beyond the generic set, each with a reason:

- **Icon** — a wrapper is required because no icon assets were supplied; it centralises the Lucide substitution so a future swap is one file.
- **Figure** — every monetary amount must render identically (tabular mono, ro-MD separators, true minus). Plain text amounts break column alignment in registers.
- **DataTable** — the ledger table *is* the product. Registers, journals and trial balances all share one header/row/totals treatment.
- **StatTile** — dashboards need a single KPI treatment so the headline figure is unambiguous.
- **Crest** / **Ornament** — the only sanctioned way to place the supplied raster brand art; prevents anyone redrawing the crest.
- **Field** — label/hint/error scaffold, so form rhythm cannot drift between screens.
- **EmptyState** — used honestly throughout the UI kit to mark views the source material did not define.

### UI kits

- `ui_kits/evidenta-app/index.html` — Autentificare → Panou de control → Registrul jurnal → Notă contabilă nouă → Balanţa de verificare. Also a starting point.
- `ui_kits/evidenta-app/login.html` — the login screen on its own.

No marketing website, docs site or slide template was supplied, so none were built.

---

## CONTENT FUNDAMENTALS

**The voice is a registrar, not a salesperson.** It states what is recorded and what happens next.
The brand's own words set the register: *autoritate*, *fundamental*, *sistem*. Nothing is playful.

**Language.** Romanian (ro-MD) throughout the product, with Romanian diacritics (`ş`, `ţ`, `ă`, `î`,
`â`) always typed correctly — `Balanţă`, not `Balanta`. Statutory terms are used in their exact legal
form and never paraphrased: *notă contabilă*, *balanţă de verificare*, *registrul jurnal*, *factură
fiscală*, *contragent*, *IDNO*, *cod fiscal*, *SNC*, *SFS*, *TVA-12*, *rulaj*, *sold iniţial / sold
final*, *stornare*.

**Person.** The product addresses the accountant with the formal plural **dumneavoastră** form, and
never with `tu`: *"Selectaţi o altă perioadă"*, *"Utilizaţi datele emise de administratorul
companiei"*. The system never says *I* and never claims agency — it reports:
*"Nota NC-00421 a fost înregistrată"* (passive: the note was recorded), not *"Am înregistrat nota"*.

**Casing.** Sentence case for everything readable — labels, buttons, headings, help text.
**UPPERCASE, tracked at 0.14em, is reserved** for two things only: the eyebrow/ribbon voice
(`SISTEM CONTABIL FUNDAMENTAL`, table headers, KPI labels) and status badges (`VALIDAT`,
`ÎN AŞTEPTARE`). Never a sentence in caps.

**Numbers are content.** Moldovan convention, without exception: space as thousands separator, comma
as decimal separator, two decimals always, currency after the amount — `48 900,00 MDL`. Negative
amounts use a true minus sign `−`, not a hyphen. Dates are `18.06.2026`. Periods are named, not
abbreviated: *Trimestrul II 2026*, *Iunie 2026*.

**Button labels are verbs, in the imperative plural.** `Înregistrează`, `Salvează ciorna`,
`Tipăreşte`, `Export TVA`, `Anulează`. One to three words. Never `OK`, never `Trimite formularul`.

**Errors name the rule that was broken and the fix**, in one sentence:
*"IDNO-ul trebuie să conţină 13 cifre."* — not *"Câmp invalid"*. Destructive confirmations state the
irreversible consequence explicitly: *"Nota NC-00421 va fi înregistrată în jurnal şi nu mai poate fi
editată."*

**Empty states are honest.** If a register has no rows, say which period is empty and what to do:
*"Niciun document în această perioadă. Selectaţi o altă perioadă sau înregistraţi prima notă
contabilă."*

**No emoji. Ever.** Not in the product, not in marketing, not in error messages. The brand's
authority depends on it. No exclamation marks. No "Oops", no "Great!", no congratulation copy after
a routine posting — a posting is confirmed, not celebrated.

**Vibe in one line:** the Monitorul Oficial, if it had been designed properly.

---

## VISUAL FOUNDATIONS

### Colour

Two brand colours and one paper. **Navy** (`--navy-700` `#0F2C52`) is authority: primary actions,
sidebar, headings, the crest ring. **Gold** (`--gold-500` `#C6A15B`) is the ledger accent: eyebrows,
the active-tab underline, the 2px totals rule, the top edge of a ceremonial card, and exactly one
`variant="gold"` CTA per view. Gold is never a large fill and never body text — as text on light it
must be `--gold-700` or darker for contrast. **Parchment** (`--surface-page` `#FAF6EE`) is the page;
cards are pure white on top of it, so a card reads as a document laid on a desk. Ink neutrals are
warm-shifted (`#3D3A33`, not `#333`) so nothing looks blue-grey against the parchment.

Semantics follow the ledger, not a generic UI palette: **credit is green, debit is red** (`--credit-*`,
`--debit-*`), amber for caution, blue-teal for information. A negative amount is red *because it is
negative*, not because something is wrong.

Only four pairings are sanctioned: parchment-on-navy, navy-on-parchment, navy-on-gold (CTA only),
ink-on-white. See `guidelines/colors-pairings.html`.

### Type

Four roles, four families:

- **Display** — Libre Baskerville 700. The crest wordmark voice: page titles, headline figures, print covers. `--text-display-1` 44/1.08 down to `--text-title` 20/1.3.
- **Eyebrow** — Barlow Condensed 600, uppercase, tracked 0.14em. The ribbon voice: table headers, KPI labels, badges, section kickers. Never lowercase, never untracked.
- **Body/UI** — Source Sans 3. 15px default, 17px for lead copy, 13px for secondary. Measure capped at 66ch.
- **Figures** — IBM Plex Mono 500, `font-variant-numeric: tabular-nums`. Every amount and account code, always right-aligned in tables.

The wordmark is always caps, 700, tracked 0.06em. The tagline sits under it in condensed caps at
0.14em, optionally flanked by gold hairlines.

### Spacing & layout

4px base, `--space-1` … `--space-24`. Cards pad 24, pages pad 32, sections gap 48. Row heights are
tokens, not guesses: 36px dense (long registers), 44px default, 52px comfortable (summaries).
Controls are 32/40/48. The shell is a **fixed 248px navy sidebar** and a **fixed 64px white topbar**;
only the main column scrolls. Content is capped at 1180px and centred — ledgers must not stretch to
ultrawide, because column alignment is the point.

### Backgrounds

No photography, no illustration, no hand-drawn anything. Four surface treatments exist and that is
all: flat parchment (pages), flat white (cards), the **navy crest gradient** `--gradient-crest`
(sidebar, login panel, the one inverse KPI tile), and the **gold foil gradient**
`--gradient-gold-foil` (3px card top rules, progress fills). There is a subtle 3px
`--texture-parchment` dot grid available for print covers — used sparingly, never behind body text.
The one decorative move permitted: a supplied crest layer (`circular-border-navy.png`) bled off a
navy panel edge at ~12% opacity, as on the login screen. **Never full-bleed imagery.**
`--gradient-protect-top` exists for the rare case of text over an image.

### Shape, borders, shadows

Institutional documents have square corners; only controls soften. `--radius-control` **5px**,
`--radius-card` **6px**, `--radius-sheet` **8px** — 8px is the ceiling. Pills exist only for `Tag`
and avatars. Borders are 1px hairlines in `--ink-200`; a 2px gold rule marks a totals row; a 3px
gold-foil bar marks a ceremonial card or dialog.

Shadows are **navy-tinted and shallow** — `rgba(6,21,39,…)`, never neutral black, never soft and
wide. `--shadow-card` is 1px+1px at 6%/4%: barely there. `--shadow-overlay` (12px at 18%) is the only
deep one, for dialogs. Fields carry a 1px **inset** shadow at rest, so an input reads as a slot cut
into the paper. Focus is a 3px navy ring (`--ring-focus`), plus a border colour change — never colour
alone.

**Cards, precisely:** white fill, 1px `--ink-200` border, 6px radius, `--shadow-card`, 24px padding,
optional condensed gold eyebrow above a serif title, optional 3px gold foil top rule. That is the
card. Coloured left borders are **not** part of this system — the single exception is the 3px tone bar
on `Toast`.

### Transparency & blur

Almost never. Two sanctioned uses: the dialog scrim (navy at 42% with a **2px** blur — just enough to
push the page back) and gold/white at 6–22% alpha for sidebar hover and active states, where a solid
tint would fight the navy gradient. No frosted-glass panels, no translucent cards.

### Animation

Motion confirms; it never performs. Durations: 80/140/200/320ms. Easing:
`cubic-bezier(.2,0,.2,1)` standard — **no springs, no bounce, no overshoot**. Hover is a **colour
change only** (navy 700→600; on light surfaces a `--navy-050` wash) — never a lift, never a scale-up.
Press is a **0.995 scale** and nothing else — no colour flash. Overlays fade in over 200ms with a 4px
rise. Toasts fade. **Numbers never count up or animate** — a figure of record appears at its value.
`prefers-reduced-motion` zeroes every duration token.

### Imagery

The only imagery is the crest itself. Its colour vibe: **cool navy against warm gold on warm
off-white paper**, matte, with a faint paper grain in the supplied lockup JPEGs — no gloss, no
neon, no cool-grey. If real photography is ever introduced it should be desaturated and warm, but
none was supplied, so **use the crest art or nothing**.

---

## ICONOGRAPHY

**No icon assets were supplied.** There is no icon font, no SVG sprite, no PNG icon set anywhere in
the source material — only crest layers. This is a **flagged substitution**:

- **Set:** [Lucide](https://lucide.dev) (2px outline, round caps), loaded from
  `cdn.jsdelivr.net/npm/lucide-static@latest`. Chosen because its 2px outline weight and open counters are the
  closest match to the crest's line work (compare the owl and laurel outlines in
  `assets/owl-outline-gold.png`).
- **Mechanism:** the `Icon` component fetches the SVG once and **inlines** it, so its
  `stroke="currentColor"` inherits the surrounding text colour and can be navy, gold, green or
  red without a second asset. This is the only sanctioned way to place a UI icon.
- **Never** hand-roll an inline SVG, and never redraw a crest element as an icon.

**Sizes:** 16 in dense tables, 18 default (body, buttons), 20 in sidebar nav, 24 in empty states.
Icons are `--text-faint`/`--ink-300` at rest inside fields and rows; `--gold-400` when marking the
active sidebar item on navy; semantic colour only when the icon carries meaning (`trending-up` green,
`alert-octagon` red).

**Brand marks are raster, not icons.** `assets/emblem-crest.png` and the ornament layers are placed
via the `Crest` and `Ornament` components. They are decorative art at 24px+ — never used as a 16px UI
glyph, never recoloured, never redrawn in SVG or CSS. The single exception is `Ornament kind="rule"`,
a gold hairline with a rotated square lozenge, which is drawn in CSS because it is a geometric rule
rather than a mark.

**Emoji: never.** **Unicode as iconography: only two characters**, both typographic rather than
decorative — the true minus `−` in negative figures and the `·` middot as an inline separator in
metadata rows.

**Asset inventory** (`assets/`): `emblem-crest.png` (the full crest), `owl-outline-gold.png`,
`owl-perched-gold.png`, `owl-alt-gold.png`, `laurel-branch-gold.png` (+`-2`),
`ribbon-banner-navy.png` (+`-2`), `column-navy.png`, `circular-border-navy.png`, and six lockup
JPEGs: `lockup-vertical-ribbon`, `lockup-horizontal`, `lockup-gold-foil`, `lockup-navy-gold`,
`lockup-stacked-serif`, `mark-minimal-circle`. All supplied by the brand; none drawn by me.

---

## Using this system

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, Card, DataTable, Figure, Crest } = window.EvidentaDesignSystem_dfa13b;
</script>
```

Rules of thumb: every amount goes through `Figure`; every register is a `DataTable`; every glyph is
an `Icon`; the identity is only ever placed with `Crest`. Reach for a token before a literal value —
if you find yourself typing `#0F2C52`, use `var(--navy-700)`.
