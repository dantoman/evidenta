repo: dantoman/evidenta
branch: main
path: frontend/src

## Last sync

date: 2026-08-30
source: local mounted folder `evidenta` (frontend read in full; commit not known)

### Updated in this project

- Recreated the current React UI (14 screens) as a faithful reference file.
- Rebuilt the whole app in the Evidenta design system: navy sidebar shell, dense grids, gold accents.
- Added a new Panou de control screen (KPI tiles, last entries, filing deadlines) — no equivalent in the code yet.
- States covered per screen: date reale, gol, eroare de la server, se încarcă.

## Screen map

| Screen (project) | Repo files |
|---|---|
| Autentificare | frontend/src/app/auth/LoginScreen.tsx, app/auth/devCode.ts, locales/ro.ts |
| Shell (sidebar + topbar) | frontend/src/app/layout/AppLayout.tsx, app/App.tsx, index.css |
| Companii | frontend/src/app/companies/CompaniesScreen.tsx, shared/api/companies.ts |
| Parteneri | frontend/src/app/partners/PartnersScreen.tsx |
| Plan de conturi | frontend/src/app/accounting/ChartOfAccountsScreen.tsx |
| Iniţializare plan | frontend/src/app/accounting/ChartSetupScreen.tsx |
| Cont (fişa contului) | frontend/src/app/accounting/AccountScreen.tsx |
| Notă contabilă manuală | frontend/src/app/accounting/ManualEntryScreen.tsx, shared/EntryGrid/index.tsx |
| Registrul înregistrărilor | frontend/src/app/accounting/RegisterScreen.tsx, app/accounting/EntryDetail.tsx |
| Balanţa de verificare | frontend/src/app/accounting/TrialBalanceScreen.tsx |
| Fişa contului (raport) | frontend/src/app/accounting/AccountLedgerScreen.tsx, app/accounting/ReportHeader.tsx |
| Cartea Mare | frontend/src/app/accounting/GeneralLedgerScreen.tsx |
| Rulaje pe corespondenţe | frontend/src/app/accounting/CorrespondenceScreen.tsx |
| Solduri iniţiale | frontend/src/app/accounting/OpeningBalancesScreen.tsx, shared/api/opening.ts |
| Şabloane de operaţiuni | frontend/src/app/accounting/OperationTemplatesScreen.tsx |
| Grile, formatare, refuzuri | frontend/src/shared/DataGrid/index.tsx, shared/format/index.ts, shared/Failure.tsx |

Project files: `Evidenta.dc.html` (redesign, Evidenta design system) · `Evidenta — cod actual.dc.html` (recreation of today's UI).
